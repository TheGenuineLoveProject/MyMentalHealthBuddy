import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { ArrowLeft, Smile, Frown, Meh, Sun, Moon, Zap, Check, Sparkles } from "lucide-react";
import { apiRequest, queryClient } from "../lib/queryClient.js";
import SEO from "../components/SEO.jsx";

const EMOTIONS = [
  { name: "Happy", icon: Smile, color: "var(--mood-happy)", bgColor: "var(--mood-happy-soft)" },
  { name: "Sad", icon: Frown, color: "var(--mood-sad)", bgColor: "var(--mood-sad-soft)" },
  { name: "Neutral", icon: Meh, color: "var(--text-secondary)", bgColor: "var(--border-light)" },
  { name: "Anxious", icon: Zap, color: "var(--mood-anxious)", bgColor: "var(--mood-anxious-soft)" },
  { name: "Calm", icon: Sun, color: "var(--mood-calm)", bgColor: "var(--mood-calm-soft)" },
  { name: "Tired", icon: Moon, color: "var(--mood-tired)", bgColor: "var(--mood-tired-soft)" },
];

const ACTIVITIES = [
  "Work", "Exercise", "Social", "Rest", "Hobby", "Self-care", "Family", "Outdoors"
];

export default function MoodPage() {
  const [, setLocation] = useLocation();
  const [rating, setRating] = useState(5);
  const [emotion, setEmotion] = useState("");
  const [activities, setActivities] = useState([]);
  const [content, setContent] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const saveMutation = useMutation({
    mutationFn: (data) => apiRequest("POST", "/api/mood", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      setSuccess(true);
      setTimeout(() => setLocation("/dashboard"), 1500);
    },
    onError: (err) => {
      setError(err.message || "Failed to save mood");
    },
  });

  function toggleActivity(activity) {
    setActivities((prev) =>
      prev.includes(activity)
        ? prev.filter((a) => a !== activity)
        : [...prev, activity]
    );
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    saveMutation.mutate({
      rating,
      emotion,
      activities,
      content,
      score: rating,
    });
  }

  function getMoodColor() {
    if (rating <= 3) return "var(--mood-sad)";
    if (rating <= 5) return "var(--mood-anxious)";
    if (rating <= 7) return "var(--mood-calm)";
    return "var(--mood-happy)";
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-mesh" role="status" aria-label="Mood saved successfully">
        <div className="text-center animate-scale-in">
          <div className="w-24 h-24 rounded-full bg-[var(--accent-teal-soft)] flex items-center justify-center mx-auto mb-6">
            <Check className="w-12 h-12 text-[var(--accent-teal)]" aria-hidden="true" />
          </div>
          <h2 className="text-3xl font-bold mb-2">Mood Saved!</h2>
          <p className="text-[var(--text-secondary)]">Redirecting to dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <SEO 
        title="Log Mood"
        description="Track your emotional state and well-being. Log your daily mood, select emotions, and note activities that affect how you feel."
      />
      <div className="min-h-screen p-6 bg-gradient-mesh">
        <div className="max-w-lg mx-auto">
          {/* Header */}
          <header className="flex items-center gap-4 mb-8">
            <Link 
              href="/dashboard" 
              className="p-3 rounded-xl bg-[var(--card)] border border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text)] hover:border-[var(--primary-light)] transition shadow-sm" 
              data-testid="link-back" 
              aria-label="Back to dashboard"
            >
              <ArrowLeft className="w-5 h-5" aria-hidden="true" />
            </Link>
            <div>
              <h1 className="text-3xl font-bold tracking-tight" data-testid="text-title">Track Your Mood</h1>
              <p className="text-[var(--text-secondary)] text-sm mt-1">How are you feeling right now?</p>
            </div>
          </header>

          {error && (
            <div className="mb-6 p-4 rounded-xl bg-[var(--accent-rose-soft)] border border-[var(--accent-rose)]/30 text-[var(--accent-rose)]" role="alert" data-testid="text-error">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8" data-testid="form-mood" aria-label="Mood tracking form">
            {/* Rating Slider */}
            <fieldset className="card-elevated p-6">
              <legend className="text-lg font-semibold mb-6 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[var(--primary)]" aria-hidden="true" />
                How are you feeling? (1-10)
              </legend>
              <div className="relative">
                <div className="flex items-center justify-center mb-4">
                  <span 
                    className="text-6xl font-bold transition-colors duration-300"
                    style={{ color: getMoodColor() }}
                    data-testid="text-rating"
                    aria-hidden="true"
                  >
                    {rating}
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={rating}
                  onChange={(e) => setRating(Number(e.target.value))}
                  className="w-full h-3 rounded-full appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, var(--mood-sad) 0%, var(--mood-anxious) 40%, var(--mood-calm) 70%, var(--mood-happy) 100%)`,
                  }}
                  data-testid="input-rating"
                  aria-label={`Mood rating: ${rating} out of 10`}
                  aria-valuemin={1}
                  aria-valuemax={10}
                  aria-valuenow={rating}
                />
                <div className="flex justify-between text-sm text-[var(--text-muted)] mt-3" aria-hidden="true">
                  <span>Very Low</span>
                  <span>Okay</span>
                  <span>Very High</span>
                </div>
              </div>
            </fieldset>

            {/* Emotion Selection */}
            <fieldset className="card-elevated p-6">
              <legend className="text-lg font-semibold mb-4">Select an emotion</legend>
              <div className="grid grid-cols-3 gap-3" role="radiogroup" aria-label="Emotion selection">
                {EMOTIONS.map(({ name, icon: Icon, color, bgColor }) => (
                  <button
                    key={name}
                    type="button"
                    onClick={() => setEmotion(name)}
                    className={`p-4 rounded-xl border-2 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--primary)] ${
                      emotion === name
                        ? "border-[var(--primary)] shadow-lg scale-105"
                        : "border-[var(--border)] hover:border-[var(--text-muted)] bg-[var(--card)]"
                    }`}
                    style={{
                      backgroundColor: emotion === name ? bgColor : undefined,
                    }}
                    data-testid={`button-emotion-${name.toLowerCase()}`}
                    aria-pressed={emotion === name}
                    aria-label={`Select emotion: ${name}`}
                  >
                    <Icon 
                      className="w-8 h-8 mx-auto mb-2 transition-transform" 
                      style={{ color: color }}
                      aria-hidden="true" 
                    />
                    <span className="text-sm font-medium">{name}</span>
                  </button>
                ))}
              </div>
            </fieldset>

            {/* Activities */}
            <fieldset className="card-elevated p-6">
              <legend className="text-lg font-semibold mb-4">Activities today</legend>
              <div className="flex flex-wrap gap-2" role="group" aria-label="Activity selection">
                {ACTIVITIES.map((activity) => (
                  <button
                    key={activity}
                    type="button"
                    onClick={() => toggleActivity(activity)}
                    className={`px-4 py-2 rounded-full border-2 transition-all duration-200 font-medium focus:outline-none focus:ring-2 focus:ring-[var(--primary)] ${
                      activities.includes(activity)
                        ? "border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)]"
                        : "border-[var(--border)] bg-[var(--card)] hover:border-[var(--text-muted)] text-[var(--text-secondary)]"
                    }`}
                    data-testid={`button-activity-${activity.toLowerCase()}`}
                    aria-pressed={activities.includes(activity)}
                  >
                    {activity}
                  </button>
                ))}
              </div>
            </fieldset>

            {/* Notes */}
            <div className="card-elevated p-6">
              <label htmlFor="mood-notes" className="text-lg font-semibold mb-4 block">Notes (optional)</label>
              <textarea
                id="mood-notes"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Any thoughts you'd like to add..."
                rows={4}
                className="input-lg resize-none"
                data-testid="input-notes"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={saveMutation.isPending}
              className="btn btn-gradient w-full text-lg py-5"
              data-testid="button-submit"
              aria-busy={saveMutation.isPending}
            >
              {saveMutation.isPending ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" aria-hidden="true" />
                  Saving...
                </>
              ) : (
                <>
                  <Check className="w-5 h-5" aria-hidden="true" />
                  Save Mood Entry
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
