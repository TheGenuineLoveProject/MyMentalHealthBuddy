import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import session from 'express-session';
import pg from 'pg';
import connectPgSimple from 'connect-pg-simple';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express(); // IMPORTANT: define app BEFORE any app.get/app.use

// --- basic middleware ---
app.use(helmet());
app.use(compression());
app.use(express.json({ limit: '1mb' }));

app.use(
  cors({
    origin: true,
    credentials: true
  })
);

// --- sessions (MemoryStore only in dev; Postgres store in production) ---
const isProd = process.env.NODE_ENV === 'production';
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev_only_change_me';

let sessionStore;
if (isProd && process.env.DATABASE_URL) {
  const PgSession = connectPgSimple(session);
  const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
  sessionStore = new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true });
  console.log('[sessions] Using Postgres session store');
} else {
  console.log('[sessions] Using MemoryStore (dev only)');
}

app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: isProd
    }
  })
);

// --- health ---
app.get('/health', (_req, res) => res.json({ ok: true, app: 'The Genuine Love Project' }));

// --- serve Vite build ---
const distPath = join(__dirname, '..', 'client', 'dist');
app.use(express.static(distPath));

// SPA fallback - serve index.html for all non-API routes
app.get('*', (_req, res) => {
  res.sendFile(join(distPath, 'index.html'));
});

const port = Number(process.env.PORT || 5000);
app.listen(port, '0.0.0.0', () => console.log(`✅ server running on :${port}`));
