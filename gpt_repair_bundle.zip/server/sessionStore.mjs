import session from 'express-session';
import pg from 'pg';
import connectPgSimple from 'connect-pg-simple';

export function createSessionMiddleware() {
  const PgSession = connectPgSimple(session);

  const hasDb = !!process.env.DATABASE_URL;

  // If no DB yet, fallback to MemoryStore for local dev only
  if (!hasDb) {
    return session({
      secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        sameSite: 'lax',
        secure: false
      }
    });
  }

  const pool = new pg.Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_URL.includes('sslmode=require') ? { rejectUnauthorized: false } : undefined
  });

  return session({
    store: new PgSession({
      pool,
      tableName: 'sessions'
    }),
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: true // trust proxy enabled above
    }
  });
}