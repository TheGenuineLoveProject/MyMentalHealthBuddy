# MyMentalHealthBuddy – CI/CD & Self-Healing Overview

This project uses **one master GitHub Actions workflow**:

- File: `.github/workflows/mmb-master.yml`
- Name: `MyMentalHealthBuddy-Master-AutoEvolution`

## Pipeline Stages

1. **diagnose** – runs basic diagnostics and the local automation suite.
2. **security** – runs `npm audit` (high+ severity), soft-fail.
3. **autoheal** – runs `scripts/autoheal-project.mjs`, soft-fail.
4. **verify** – must pass; runs verification suite and fails if AutoHeal suggestions remain.
5. **build** – builds frontend (`client`) and backend (`server`), then uploads artifacts.
6. **deploy** – triggers Replit Autoscale deploy using `REPLIT_TOKEN`.
7. **healer** – runs `scripts/healer-orchestrator.mjs` with `GH_TOKEN` to propose healing changes.
8. **daily** – when triggered by cron, runs UI/API/types/critical scans.

## Secrets Used

Set these in **GitHub → Settings → Secrets and variables → Actions → Secrets**:

- `REPLIT_TOKEN` – Replit deploy token.
- `GH_TOKEN` – fine-grained GitHub PAT with `repo` and `workflow` permissions.

## How To Use

- **Normal push to `main`**  
  → full pipeline runs: diagnose → security → autoheal → verify → build → deploy → healer.

- **Manual run**  
  In the *Actions* tab, select `MyMentalHealthBuddy-Master-AutoEvolution` → *Run workflow*.

- **Daily automatic scan**  
  Triggered by the cron schedule `0 10 * * *` (10:00 UTC).

## Troubleshooting

- Check the **first failing job** in the pipeline; earlier jobs must succeed.
- If `verify` fails due to AutoHeal suggestions:
  1. Open the relevant file.
  2. Apply or clean up the suggestion.
  3. Commit and push again.

- If `deploy` fails:
  - Make sure `REPLIT_TOKEN` is set and not expired.
  - Confirm Replit project name and permissions.

- If `healer` fails:
  - Make sure `GH_TOKEN` is valid and has `contents: write` and `pull-requests: write` scopes.
  - Confirm `scripts/healer-orchestrator.mjs` exists and runs locally with `node`.